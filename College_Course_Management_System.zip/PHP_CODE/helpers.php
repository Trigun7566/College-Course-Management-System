<?php

// Below function to dictate how pages act if the page request method is post, will return True value 
function is_post_request(): bool
{
    return strtoupper($_SERVER['REQUEST_METHOD']) === 'POST';
}

?>