<?php
    error_reporting(E_ALL ^ E_NOTICE);
    session_start();
?>
<!DOCTYPE lang="en">
<head>
    <title> Profile Page </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php require 'master.php';
?>
    <div class="container text-center" style=" 
            background: yellow;
            border-radius: 50px;">
        <?php
            // If employee information is no longer contained in $_SESSION superglobal then we will regather that information from logged in user
            if( isset($_SESSION['student']))
            {
                $student = $_SESSION['student'];
                $email = $student['0'];
                $password = $student['1'];
                $first_name = $student['2'];
                $last_name = $student['3'];
                $address = $student['4'];
                $phone = $student['5'];
                echo '<b><div style="font-size:1.2em"> STUDENT INFORMATION </b></div></br>';
                echo '<b><div style="font-size:1em"> First Name: </b>'. $first_name ."</div></br>";
                echo '<b><div style="font-size:1em"> Last Name: </b>'. $last_name ."</div></br>";
                echo '<b><div style="font-size:1em"> Email: </b>'. $email ."</div></br>";
                echo '<b><div style="font-size:1em"> Password: </b>'. $password ."</div></br>";
                echo '<b><div style="font-size:1em"> Address: </b>'. $address ."</div></br>";
                echo '<b><div style="font-size:1em"> Phone: </b>'. $phone ."</div></br>";
            }
            elseif( isset($_SESSION['teacher']))
            {
                $teacher = $_SESSION['teacher'];
                $email = $teacher['0'];
                $password = $teacher['1'];
                $first_name = $teacher['2'];
                $last_name = $teacher['3'];
                echo '<b><div style="font-size:1.2em"> INSTRUCTOR INFORMATION </b></div></br>';
                echo '<b><div style="font-size:1em"> First Name: </b>'. $first_name ."</div></br>";
                echo '<b><div style="font-size:1em"> Last Name: </b>'. $last_name ."</div></br>";
                echo '<b><div style="font-size:1em"> Email: </b>'. $email ."</div></br>";
                echo '<b><div style="font-size:1em"> Password: </b>'. $password ."</div></br>";
            }
            else
            {
                session_destroy();
                header('Location: login.php');
            }            
        ?>
    </div>

<?php require_once 'footer.php';?>
</body>
</html>
