<?php
    require_once 'connectDB.php';
    error_reporting(E_ALL ^ E_NOTICE);
    session_start();
    
    if (strtoupper($_SERVER['REQUEST_METHOD']) === 'POST') {
        // Gathering user input and converting into variables
        $ctitle = $_POST['course'];

        // Loop through all variables stored in the $_POST array
        foreach($_POST as $value) 
        {
            if(empty($value))  // If any of the $_POST variables are empty, set $validation to false
            {
                $validation = False;
            }
        }
        
        $student = $_SESSION['student'];
        $email = $student['0'];
        $obj = new Database();
        $con = $obj->connectDB('localhost','root','','cornelius_college');
        
        // Getting Student ID for student in course
        $s="SELECT s_id FROM students WHERE email='$email'";                 
        $te=$obj->executeQuery($con, $s);
        $tes = mysqli_fetch_assoc($te['1']);
        $sid = '';
        foreach ($tes as $a){
            $sid = $a;
        }

        // Getting course ID for this course
        $s2="SELECT c_id FROM courses WHERE title='$ctitle'";
        $te2=$obj->executeQuery($con, $s2);
        $tes2 = mysqli_fetch_assoc($te2['1']);
        $cid = '';
        foreach ($tes2 as $a2){
            $cid = $a2;
        }

        // Getting instructor name for course
        $s3="SELECT instructor FROM courses WHERE title='$ctitle'";
        $te3=$obj->executeQuery($con, $s3);
        $tes3 = mysqli_fetch_assoc($te3['1']);
        $ln = '';
        foreach ($tes3 as $a3){
            $ln = $a3;
        }
        $lna = explode(' ',$ln);
        $iname = $lna['1'];
        
        // Getting instrutor id for instructor of course
        $s4="SELECT i_id FROM instructors WHERE lname='$iname'";
        $te4=$obj->executeQuery($con, $s4);
        $tes4 = mysqli_fetch_assoc($te4['1']);
        $iid = '';
        foreach ($tes4 as $a4){
            $iid = $a4;
        }

        // for verifying the total courses by a student
        $sql="SELECT count(s_id) FROM classes WHERE s_id='$sid'";                 
        $r=$obj->executeQuery($con, $sql);
        $herd = '';
        $result = $r['1'];
        foreach ($result as $val){
            foreach ($val as $value){
                $herd=$value;
            }
        }
        if ($herd >= 3)
        {
            $msg1 = "ERROR IN REGISTRATION (YOU HAVE ALREADY BEEN ASSIGNED 3 COURSES)";
            $_SESSION['error1'] = $msg1;
            header('Location: student_add_course3.php');
            $validation=False;
            exit();
        }
        else{
            //making sure that session variable is not set currently for this error
            $validation = True;
            if ( isset($_SESSION['error1'])){
                unset($_SESSION['error1']);
            }
        }

        // Gathering amount of students allowed for this course
        $se3="SELECT max_students FROM courses WHERE title='$ctitle'";
        $t3=$obj->executeQuery($con, $se3);
        $res3 = mysqli_fetch_assoc($t3['1']);
        $ln2 = '';
        foreach ($res3 as $x3){
            $ln2 = $x3;
        }

        // Verifying the total students in the course does not go over the max, if it does we will establish a method to add the user to the wait list
        $sql2="SELECT count(cl_name) FROM classes WHERE cl_name='$ctitle'";                 
        $r1=$obj->executeQuery($con, $sql2);
        $herd2 = '';
        $result2 = $r1['1'];
        foreach ($result2 as $val2)
            {
            foreach ($val2 as $value2){
                $herd2=$value2;
            }
        }

        if($herd2 >= $ln2)
        {
            $validation = False;
            $msg2 = "ERRROR IN REGISTRATION(MAXIMUM STUDENTS IN A COURSE HAS BEEN REACHED)";
            $_SESSION['error2'] = array($msg2, $ctitle, $sid);
            header('Location: student_add_course3.php');
            exit();
        }
        else{
            $validation = True;
            //making sure that session variable is not set currently for this error
            if (isset($_SESSION['error2'])){
                unset($_SESSION['error2']);
            }
        }

        // for verifying that if student has already registered for the course
        $sql3="SELECT cl_name FROM classes WHERE cl_name='$ctitle' AND s_id='$sid'";                 
        $r2=$obj->executeQuery($con, $sql3);
        if(mysqli_num_rows($r2['1']) != 0)
        {
            $validation = False;
            $msg3 = "COURSE ALREADY REGISTERED BY STUDENT";
            $_SESSION['error3'] = $msg3;
            header('Location: student_add_course3.php');
            exit();
        }
        else{
            $validation = True;
            //making sure that session variable is not set currently for this error
            if ( isset($_SESSION['error3'])){
                unset($_SESSION['error3']);
            }
        }

        $clid = $obj->countEnrolledCourses($con);

        // If none of the variables were empty, $Validation will have remained true
        if($validation == True) {
            $sql5 = "INSERT INTO `Classes`(`cl_number`, `cl_name`, `c_id`, `i_id`, `s_id`) 
                    VALUES ('$clid','$ctitle','$cid','$iid', '$sid')";
            $obj->executeQuery($con, $sql5);
            header('Location: courses.php');
        }
    }
?>

<!DOCTYPE lang="en">
<head>
    <title> Student Course Registration Page </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php require 'master.php';?>

<div class="container text-center">
    <h1> Student Course Registration Page </h1>
    <?php
    if ( isset($_SESSION['semester']))
        {
        $semester = $_SESSION['semester'];
        $obj = new Database();
        $con = $obj->connectDB('localhost','root','','cornelius_college');
        if ($semester == "all"){
            $sql2 = "SELECT courses.title from courses";
        }
        else{
            $sql2 = "SELECT courses.title from courses WHERE semester='$semester'";
        }
        $ret2=$obj->executeQuery($con, $sql2);
        $herd2 = [];
        $result2 = $ret2['1'];
        foreach ($result2 as $val2){
            foreach ($val2 as $value2){
                $herd2[]=$value2;
            }
        }
    }
    ?>
    <form action='student_add_course3.php' method='post'>
        <label for='course'>Please select a course from the dropdown list to register: </label>
        <select class='dropdownstyle' name='course' selected='$herd'>
        <option value=''><?php echo 'Select' ?></option>
        <?php foreach ($herd2 as $value2) { ?>
            <option selected=<?php echo $value2; ?> value=<?php echo $value2; ?>><?php echo $value2; ?></option>
        <?php } ?>
        </select>
        <input type="submit" value="Register" style="background-color:green; border-color:black; color:yellow">
    </form>    
                
        <?php
        if(isset($_SESSION["error1"])){
            $error = $_SESSION["error1"];
            echo "<i style='color:red;'><b><span>$error</span></b></i>";
        }
        
        elseif(isset($_SESSION["error2"])){
            $error = $_SESSION["error2"];
            $msg = $error['0'];
            $ctitle = $error['1'];
            $sid = $error['2'];
            $student = $_SESSION['student'];
            $email = $student['0'];

            $obj = new Database();
            $con = $obj->connectDB('localhost','root','','cornelius_college');
            $wid = $obj->countWaitingList($con);
            $sql = "INSERT INTO `Waiting_List`(`w_id`,`cname`,`s_id`,`s_email`) 
                    VALUES ('$wid','$ctitle','$sid','$email')";                 
            $ret=$obj->executeQuery($con, $sql);
            echo "<i style='color:red;'><b><span>You have been placed on the waiting list for this course!</span></b></i>";
        }

        elseif(isset($_SESSION["error3"])){
            $error = $_SESSION["error3"];
            echo "<i style='color:red;'><b><span>$error</span></b></i>";
        }
    ?>         
    </form>
</div>

<?php include 'footer.php';?>
</body>
</html>