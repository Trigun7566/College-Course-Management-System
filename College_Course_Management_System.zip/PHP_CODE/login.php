<?php
    require_once 'connectDB.php';
    error_reporting(E_ALL ^ E_NOTICE);
    session_start();
    if (strtoupper($_SERVER['REQUEST_METHOD']) === 'POST') {
        if ( isset($_POST['email']) && isset($_POST['password']) ) {
            echo "Handling student and teacher login now...";
            $validation = True; // Validated needs to be set to true, for the SQL code to run

            // Loop through all variables stored in the $_POST array
            foreach($_POST as $value) 
            {
                if(empty($value))  // If any of the $_POST variables are empty, set $validation to false
                {
                    $validation = False;
                }
            }
            
            if($validation == True) {
                // Setting variables for email and password from POST method
                $email = $_POST['email'];
                $pass = $_POST['password'];

                // Generating connection to MySQL database, selecting database record from provided email and password, if email and password are not found in database then exit
                $obj = new Database();
                $con = $obj->connectDB('localhost','root','','cornelius_college');
                $sql = "SELECT * FROM `Students` WHERE `email`='$email' AND `password`='$pass'";
                $sql2 = "SELECT * FROM `Instructors` WHERE `email`='$email' AND `password`='$pass'";
                $res = $obj->executeSelectQuery($con, $sql);
                $res2 = $obj->executeSelectQuery($con, $sql2);
                $rowcount = mysqli_num_rows( $res );
                $rowcount2 = mysqli_num_rows( $res2 );

                // if user (student or teacher) exists in database then it continues to loggedin page, however if email or password does not exist in database it returns students or instructor 
                // back to login page with error displaying that they need to re-enter their email and password
                if ($rowcount > 0) {
                    $row = mysqli_fetch_assoc($res);
                    $first_name = $row['fname'];
                    $last_name = $row['lname'];
                    $email = $row['email'];
                    $address = $row['address'];
                    $phone = $row['phone'];
                    $pass = $row['password'];
                    $student = array($email, $pass, $first_name, $last_name, $address, $phone);
                    $_SESSION['student'] = $student;
                    $_SESSION['username'] = $first_name;
                    header('Location: loggedin.php');
                }
                elseif ($rowcount2 > 0) {
                    $row2 = mysqli_fetch_assoc($res2);
                    $first_name = $row2['fname'];
                    $last_name = $row2['lname'];
                    $email = $row2['email'];
                    $pass = $row2['password'];
                    $teacher = array($email, $pass, $first_name, $last_name);
                    $_SESSION['teacher'] = $teacher;
                    $_SESSION['username'] = $first_name;
                    header('Location: loggedin.php');
                }
                else {
                    $error = 'invalid username or password, please try again';
                    $_SESSION['error'] = $error;
                    header('Location: login.php');
                }
            }
        }
    }    
?>
<!DOCTYPE lang="en">
<head>
    <title> Login Page </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php require 'master.php';
?>

    <div class="container text-center">
        <h1>Welcome to the Login page</h1>
        <form action="login.php" method="post">        
        Email: <input type="text" name="email"><br>
        Password: <input type="password" name="password"><br>
        <input type="submit">
        <?php
            if(isset($_SESSION["error"])){
                $error = $_SESSION["error"];
                echo "<i style='color:red;'><b><span>$error</span></b></i>";
            }
        ?>         
    </form>
    </div>

<?php require_once 'footer.php';?>
</body>
</html>
