<?php
    require_once 'connectDB.php';
    error_reporting(E_ALL ^ E_NOTICE);
    session_start();
    
    if (strtoupper($_SERVER['REQUEST_METHOD']) === 'POST') {
        // Gathering user input and converting into variables
        $ctitle = $_POST['category'];

        $validation = True; // Validated needs to be set to true, for the SQL code to run

        // Loop through all variables stored in the $_POST array
        foreach($_GET as $value) 
        {
            if(empty($value))  // If any of the $_POST variables are empty, set $validation to false
            {
                $validation = False;
            }
        }

        // If none of the variables were empty, $Validation will have remained true
        if($validation == True) {
            $obj = new Database();
            $con = $obj->connectDB('localhost','root','','cornelius_college');
            $sql = "DELETE from courses WHERE title='$ctitle'";
            $obj->executeQuery($con, $sql);
        }
    }
?>

<!DOCTYPE lang="en">
<head>
    <title> Course Removal Page </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php require 'master.php';?>

<?php 
    if ( isset($_SESSION['teacher'])){
        $teacher = $_SESSION['teacher'];
        $obj = new Database();
        $con = $obj->connectDB('localhost','root','','cornelius_college');
        $sql = "SELECT courses.title from courses";
        $ret=$obj->executeQuery($con, $sql);
        $herd = [];
        $result = $ret['1'];
        foreach ($result as $val){
            foreach ($val as $value){
                $herd[]=$value;
            }
        }
    }
    else 
    {
        echo "Your not authorized to be here";
        session_destroy();
        header('Location: login.php');
    }
?>
<div class="container text-center">
    <h1> Course Removal Page </h1>
    
    <form action='delete_course.php' method="post"> 
        <label for="category">Please select a course from the dropdown list to delete: </label>
        <select class="dropdownstyle" name="category" selected="<?php echo $herd; ?>">
        
        <option value=""><?php echo "Select"; ?></option>

        <?php foreach ($herd as $value) { ?>
            <option selected="<?php echo $value; ?>" value="<?php echo $value; ?>"><?php echo $value; ?></option>
        <?php } ?>
        </select>
        <input type="submit" value="Delete" style="background-color:red; border-color:black; color:white">
    </form>
</div>

<?php include 'footer.php';?>
</body>
</html>