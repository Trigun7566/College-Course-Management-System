<?php
    error_reporting(E_ALL ^ E_NOTICE);
    session_start();
    if ( isset($_SESSION['Remove_Noti'])){
        unset($_SESSION['Remove_Noti']);
    }
    elseif ( isset($_SESSION['error1'])){
        unset($_SESSION['error1']);
    }
    elseif ( isset($_SESSION['error2'])){
        unset($_SESSION['error2']);
    }
    elseif ( isset($_SESSION['error3'])){
        unset($_SESSION['error3']);
    }
?>
<!DOCTYPE lang="en">
<head>
    <title> Cornelius College Welcome Page </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php require 'master.php';
?>
    <div class="container text-center">
        <?php
            if(isset($_SESSION['student'])){
                $student = $_SESSION['student'];
                echo "<b> Welcome: ".$student['2']. " " .$student['3']. "</b>";
            }
            elseif(isset($_SESSION['teacher'])) {
                $teacher = $_SESSION['teacher'];
                echo "<b> Welcome: Instructor " .$teacher['3']. "</b>";
            }
        ?>
        <li style="font-size:20px"><b><a href="profile.php">Profile</a></b></li>
        <li style="font-size:20px"><b><a href="courses.php">Courses</a></b></li>
    </div>

<?php require_once 'footer.php';?>
</body>
</html>
