<?php
    error_reporting(E_ALL ^ E_NOTICE);

?>

<html>
<head>
<style>
* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 31.5%;
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>

<!DOCTYPE lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>

<div class="navbar-fixed-bottom row-fluid">
    <div class="navbar-inner">
        <div class="container text-center">
            <div class="row">
                <div class="column">
                    <img src='/img/data-enc.jpg' alt="encrypt" width="400"><br>
                </div>
                <div class="column">
                    <img src='/img/image_enrollment.png' alt="enrollment" width="300"><br>
                </div>
            </div>
            Copyright @ 2022
        </div>
    </div>
</div>

</body>
</html>