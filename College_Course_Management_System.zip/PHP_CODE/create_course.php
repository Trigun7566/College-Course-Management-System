<?php
    require_once 'connectDB.php';
    error_reporting(E_ALL ^ E_NOTICE);
    session_start();
    
    if (strtoupper($_SERVER['REQUEST_METHOD']) === 'POST') {
        // Gathering user input and converting into variables
        $ctitle = $_POST['course_title'];
        $ccredit = $_POST['course_credit'];
        $cdate = $_POST['course_date'];
        $cmax = $_POST['course_max'];
        $csemester = $_POST['semester'];

        $validation = True; // Validated needs to be set to true, for the SQL code to run

        // Loop through all variables stored in the $_POST array
        foreach($_POST as $value) 
        {
            if(empty($value))  // If any of the $_POST variables are empty, set $validation to false
            {
                $validation = False;
            }
        }

        // If none of the variables were empty, $Validation will have remained true
        if($validation == True) {
            if ( isset($_SESSION['teacher'])){
                $teacher = $_SESSION['teacher'];
                $teacher_name = "".$teacher['2']." ".$teacher['3']."";
                echo $teacher_name;
                $obj = new Database();
                $con = $obj->connectDB('localhost','root','','cornelius_college');
                $cid = $obj->countCourses($con);
                $sql = "INSERT INTO `Courses`(`c_id`, `title`, `credits`, `date`, `instructor`, `semester`,`max_students`) 
                        VALUES ('$cid','$ctitle','$ccredit','$cdate','$teacher_name', '$csemester', '$cmax')";
                $obj->executeQuery($con, $sql);
                echo "<b> Class ".$ctitle." created </b>";
                header('Location: courses.php');
            }
            else 
            {
                echo "Your not authorized to be here";
                session_destroy();
                header('Location: login.php');
            }
        }
    }
?>

<!DOCTYPE lang="en">
<head>
    <title> Course Creation Page </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php require 'master.php';?>
    <div class="container text-center">
    <h1> Course Creation Page</h1>
    <form action="create_course.php" method="post">    
        Course Title: <input type="text" name="course_title"><br>
        Course Credits: <input type="text" name="course_credit"><br>
        Course Max # of Students: <input type="text" name="course_max"><br>
        Course Start Date(Format: YYYY-MM-DD): <input type="text" name="course_date"><br>
        <label for="semester">Course Semester: </label>
        <?php $semester = ['summer', 'spring', 'fall']; ?>
        <select class="dropdownstyle" name="semester" selected="<?php echo $semester; ?>">
        <option value=""><?php echo "Select"; ?></option>
        <?php foreach ($semester as $value) { ?>
            <option selected="<?php echo $value; ?>" value="<?php echo $value; ?>"><?php echo $value; ?></option>
        <?php } ?>
        </select> 
        <input type="submit" value="Create" style="background-color:green; border-color:black; color:yellow">
    </form>
    </div>
<?php include 'footer.php';?>
</body>
</html>