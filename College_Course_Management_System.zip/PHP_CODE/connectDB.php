<?php

class Database{
    private $host = "localhost";
    private $database = "cornelius_college";
    private $user = "root";
    private $password = "";

    function __contruct() {
        $con = $this->connectDB();
    }

    function countUsers($con) {
        $test_query = "SELECT * FROM `Students`";
        $result = mysqli_query($con, $test_query);
        $rowcount = mysqli_num_rows( $result );
        return $rowcount + 1;
    }

    function countCourses($con) {
        $test_query = "SELECT * FROM `Courses`";
        $result = mysqli_query($con, $test_query);
        $rowcount = mysqli_num_rows( $result );
        return $rowcount + 1;
    }

    function countWaitingList($con) {
        $test_query = "SELECT * FROM `Waiting_List`";
        $result = mysqli_query($con, $test_query);
        $rowcount = mysqli_num_rows( $result );
        return $rowcount + 1;
    }

    function countEnrolledCourses($con) {
        $test_query = "SELECT * FROM `Classes`";
        $result = mysqli_query($con, $test_query);
        $rowcount = mysqli_num_rows( $result );
        return $rowcount + 1;
    }

    function connectDB($host, $user, $password, $database) {
         // connect to database
        try {
            $con = mysqli_connect($host, $user, $password, $database);
        } 
        catch(Exception $e) {
            echo 'Message: ' .$e->getMessage();
        }
        return $con;
    }

    function executeSelectQuery($con, $sql) {
        //ability to select records from database
        $result = mysqli_query($con, $sql);
        return $result;
    }

    function executeQuery($con, $sql) {
        //ability to insert, delete, or update records
        $result = mysqli_query($con, $sql);
        $affectedRows = mysqli_affected_rows($con);
        return array($affectedRows, $result);
    }
}
?>

