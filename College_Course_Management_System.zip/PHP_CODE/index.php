<?php 
    error_reporting(E_ALL ^ E_NOTICE);
?>
<html lang="en">
<head>
    <title> Home Page </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body style="background-color:orange">

<?php require 'master.php';?>
    <?php
    session_start();
    if ($_COOKIE['logout'] = 1) {
        session_destroy();
    }
    ?>
    <div class="container text-center">
    <h1><b>Welcome to the Home Page!</b></h1>
    </div>

	<div class="container text-center">
	<form action="action_page.php">
    <h2>Please choose from the following options: </h2>
		<nav>
			<ul>
                <li style="font-size:20px"><b><a href="index.php">Home</a></b></li>
                <li style="font-size:20px"><b><a href="enrollment.php">Enroll</a></b></li>
                <li style="font-size:20px"><b><a href="login.php">Login</a></b></li>
			</ul>
		</nav>
	</div>
	
<?php require_once 'footer.php';?>
</body>
</html>