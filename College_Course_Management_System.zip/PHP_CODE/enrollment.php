<?php
    require_once 'connectDB.php';
    error_reporting(E_ALL ^ E_NOTICE);
    session_start();
    
    if (strtoupper($_SERVER['REQUEST_METHOD']) === 'POST') {
        // Gathering user input and converting into variables
        $email = $_POST['email'];
        $password = $_POST['password'];
        $fname = $_POST['first_name'];
        $lname = $_POST['last_name'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];

        $validation = True; // Validated needs to be set to true, for the SQL code to run

        // Loop through all variables stored in the $_POST array
        foreach($_POST as $value) 
        {
            if(empty($value))  // If any of the $_POST variables are empty, set $validation to false
            {
                $validation = False;
            }
        }

        // Verify that user did not proivde a duplicate email address that is already in the database system
        //try {
        $obj = new Database();
        $con = $obj->connectDB('localhost','root','','cornelius_college');
        $sql2="SELECT count(email) FROM students WHERE email='$email'";                 
        $r1=$obj->executeQuery($con, $sql2);
        $herd2 = '';
        $result2 = $r1['1'];
        foreach ($result2 as $val2)
            {
            foreach ($val2 as $value2){
                $herd2=$value2;
            }
        }

        if($herd2 > 0)
        {
            $msg = "Please provide a different email address and try again";
            $_SESSION['Duplicate'] = $msg;
            header('Location: enrollment.php');
            exit();
        }
        
        // If none of the variables were empty, $Validation will have remained true
        if($validation == True) {
            // Generating connection to MySQL database, gathering current count of records in database table, placing variables into INSERT statement, then creating new record in SQL database
            $id = $obj->countUsers($con);
            $sql = "INSERT INTO `Students`(`s_id`, `email`, `password`, `fname`, `lname`, `address`, `phone`) 
                    VALUES ('$id','$email','$password','$fname','$lname','$address','$phone')";
            $obj->executeQuery($con, $sql);
            header('Location: login.php');
        }
    }
?>

<!DOCTYPE lang="en">
<head>
    <title> Student Enrollment Page </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php require 'master.php';?>
    <div class="container text-center">
    <h1> Welcome to the Student Enrollment Page</h1>
    <form action="enrollment.php" method="post">    
        Email: <input type="text" name="email"><br>
        Password: <input type="text" name="password"><br>
        First Name: <input type="text" name="first_name"><br>
        Last Name: <input type="text" name="last_name"><br>
        Address: <input type="text" name="address"><br>
        Phone: <input type="text" name="phone"><br>
        <input type="submit">
        <?php 
            if ( isset($_SESSION['Duplicate']))
            {
                $de = $_SESSION['Duplicate'];
                echo "<i style='color:red;'><b><span>$de</span></b></i>";
            }
        ?>
    </form>
    </div>
<?php include 'footer.php';?>
</body>
</html>