<?php
    require_once 'connectDB.php';
    error_reporting(E_ALL ^ E_NOTICE);
    session_start();
    
    if (strtoupper($_SERVER['REQUEST_METHOD']) === 'POST') {
        // Gathering user input and converting into variables
        $ctitle = $_POST['removal'];

        $validation = True; // Validated needs to be set to true, for the SQL code to run

        // Loop through all variables stored in the $_POST array
        foreach($_GET as $value) 
        {
            if(empty($value))  // If any of the $_POST variables are empty, set $validation to false
            {
                $validation = False;
            }
        }

        // If none of the variables were empty, $Validation will have remained true
        if($validation == True) {
            $student = $_SESSION['student'];
            $email = $student['0'];
            $obj = new Database();
            $con = $obj->connectDB('localhost','root','','cornelius_college');
            
            // Getting Student ID for logged in student
            $s="SELECT s_id FROM students WHERE email='$email'";                 
            $te=$obj->executeQuery($con, $s);
            $tes = mysqli_fetch_assoc($te['1']);
            $sid = '';
            foreach ($tes as $a){
                $sid = $a;
            }

            // Removing student from course
            $obj = new Database();
            $con = $obj->connectDB('localhost','root','','cornelius_college');
            $sql = "DELETE from classes WHERE cl_name='$ctitle' and s_id='$sid'";
            $obj->executeQuery($con, $sql);

            //check to see if there is anyone waiting for this course, and if so then assigning this new slot for this course to that student
            $sql="SELECT count(s_id) FROM waiting_list WHERE cname='$ctitle'";                 
            $r=$obj->executeQuery($con, $sql);
            $herd = '';
            $result = $r['1'];
            foreach ($result as $val){
                foreach ($val as $value){
                    $herd=$value;
                }
            }

            if ($herd > 0)
            {
                // Gather user from database that was on waiting list
                $sql2="SELECT s_id FROM waiting_list WHERE cname='$ctitle'";                 
                $r2=$obj->executeQuery($con, $sql2);
                $herd2 = [];
                $result2 = $r2['1'];
                foreach ($result2 as $val2){
                    foreach ($val2 as $value2){
                        $herd2[]=$value2;
                    }
                }
                $student = $herd2['0'];
                    
                $sql3="SELECT email FROM students WHERE s_id='$student'";                 
                $r3=$obj->executeQuery($con, $sql3);
                $herd3 = '';
                $result3 = $r3['1'];
                foreach ($result3 as $val3){
                    foreach ($val3 as $value3){
                        $herd3=$value3;
                    }
                }
                $email = $herd3;
                ini_set("SMTP","smtp-relay.gmail.com");
                ini_set("smtp_port","587");

                // Sending email notification to email address specified by student during enrollment
                $msg1 = "<h1>Course Available ".$ctitle." you have now been assigned to this course</h1>";
                $subject = "Email Notification for course availability";
                $to = $email;
                $from = 'jakeororke@gmail.com';
                mail($to, $subject, $msg1);

                // Removing student from wait list
                $obj = new Database();
                $con = $obj->connectDB('localhost','root','','cornelius_college');
                $sql = "DELETE from waiting_list WHERE s_id='$student'";
                $obj->executeQuery($con, $sql);
                header('Location: courses.php');
            }
            else
            {
                header('Location: courses.php');
            }
        }
    }
?>

<!DOCTYPE lang="en">
<head>
    <title> Course Removal Page </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php require 'master.php';?>

<?php 
    error_reporting(0);
    try{
        if ( isset($_SESSION['student'])){
            // Establishing connection to database and obtaining student ID
            $student = $_SESSION['student'];
            $email = $student['0'];
            $obj = new Database();
            $con = $obj->connectDB('localhost','root','','cornelius_college');
            $sql = "SELECT s_id FROM `Students` WHERE email='$email'";
            $res = $obj->executeSelectQuery($con, $sql);
            $tes = mysqli_fetch_assoc($res);
            $sid = '';
            foreach ($tes as $a){
                $sid = $a;
            }

            // Using student ID to obtain course ID from Classes
            $sql2 = "SELECT c_id FROM `Classes` WHERE s_id='$sid'";
            //$res2 = $obj->executeSelectQuery($con, $sql2);
            $res2 = $obj->executeQuery($con, $sql2);
            $tes2 = $res2['1'];
            $cid = [];
            foreach ($tes2 as $a)
            {
                foreach ($a as $b)
                {
                    $cid[] = $b;
                }
            }

            // Using course ID to obtain course information
            $herd = [];
            foreach ($cid as $v)
            {
                $sql3 = "SELECT * FROM `Courses` WHERE c_id=$v";
                $res3 = $obj->executeSelectQuery($con, $sql3);
                $tes3 = mysqli_fetch_assoc($res3);
                $ctitle = $tes3['title'];
                $herd[]=$ctitle;
            }

            // Checking to see if notification for no courses to be removed is currently set, will unset now since passed above checks.
            if ( isset($_SESSION['Remove_Noti'])){             
                unset($_SESSION['Remove_Noti']);
            }
        }
        else 
        {
            echo "Your not authorized to be here";
            session_destroy();
            header('Location: login.php');
        }
    }
    catch (Exception $e){
        $herd=[];
        $_SESSION['Remove_Noti'] = "No currently assigned courses for the logged in user";
        //header('Location: student_remove_course.php');
    }
?>
<div class="container text-center">
    <h1> Course Removal Page </h1>
    
    <form action='student_remove_course.php' method="post"> 
        <label for="removal">Please select a course from the dropdown list to remove: </label>
        <select class="dropdownstyle" name="removal" selected="<?php echo $herd; ?>">
        
        <option value=""><?php echo "Select"; ?></option>

        <?php foreach ($herd as $value) { ?>
            <option selected="<?php echo $value; ?>" value="<?php echo $value; ?>"><?php echo $value; ?></option>
        <?php } ?>
        </select>
        <input type="submit" value="Remove" style="background-color:red; border-color:black; color:white">
        <?php 
            if(isset($_SESSION['Remove_Noti'])){
                    $noti = $_SESSION['Remove_Noti'];
                    echo "<i style='color:red;'><b><span>$noti</span></b></i>";
            }
        ?>
    </form>
</div>

<?php include 'footer.php';?>
</body>
</html>