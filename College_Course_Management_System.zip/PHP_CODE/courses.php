<?php
    error_reporting(E_ALL ^ E_NOTICE);
    session_start();
    if (strtoupper($_SERVER['REQUEST_METHOD']) === 'POST') {
        $semester = $_POST['semester'];
        $_SESSION['semester'] = $semester;
        header('Location: student_add_course3.php');
    }
?>
<!DOCTYPE lang="en">
<head>
    <title> Course Page </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>

<?php require 'master.php';?>

<div class="container text-center" style=" 
            background: yellow;
            border-radius: 50px;
            padding-top:10px;padding-bottom:10px">
        <?php
            if( isset($_SESSION['student']))
            {   
                ?>
                <div style="font-size:20px"><b> Course Enrollment by Semester </b>
                    <form action='courses.php' style="font-size:15px" method="post"> 
                        <label for="semester">Please select a semester from the dropdown list to display available courses for registration: </label>
                        <?php $sem = ['spring', 'summer', 'fall', 'all']; ?>
                        <select class="dropdownstyle" name="semester" selected="<?php echo $sem; ?>">
                        <option value=""><?php echo "Select"; ?></option>
                        <?php foreach ($sem as $value) { ?>
                            <option selected="<?php echo $value; ?>" value="<?php echo $value; ?>"><?php echo $value; ?></option>
                        <?php } ?>
                        <input type="submit" value="Lets Go!" style="background-color:green; border-color:black; color:yellow">
                        </select>
                    </form>
                </div>        
        <?php
                echo '<li style="font-size:20px"><b><a href="student_remove_course.php">Remove Course from Schedule</a></b></li>';
            }
            elseif( isset($_SESSION['teacher']))
            {
                echo '<li style="font-size:20px"><b><a href="create_course.php">Create Course</a></b></li>';
                echo '<li style="font-size:20px"><b><a href="delete_course.php">Delete Course</a></b></li>';                
            }
            else
            {
                session_destroy();
                header('Location: loggedin.php');
            }            
        ?>
</div>

<?php    
    if( isset($_SESSION['student']))
        {
        try    
            {
            require_once 'connectDB.php';
            // Establishing connection to database and obtaining student ID
            $student = $_SESSION['student'];
            $email = $student['0'];
            $obj = new Database();
            $con = $obj->connectDB('localhost','root','','cornelius_college');
            $sql = "SELECT s_id FROM `Students` WHERE email='$email'";
            $res = $obj->executeSelectQuery($con, $sql);
            $tes = mysqli_fetch_assoc($res);
            $sid = '';
            foreach ($tes as $a){
                $sid = $a;
            }

            echo '<div class="container text-center" style=" 
            background: white;
            border-radius: 50px;padding-top:10px;padding-bottom:10px">';
            echo '<div style="font-size:20px"><b> Current Enrolled Courses </b></div>';
            echo '<div style="font-size:20px"><b>  Course   |   Start Date   |   End Date   |   Instructor </b></div>';
            
            // Using student ID to obtain course ID from Classes
            $sql2 = "SELECT c_id FROM `Classes` WHERE s_id='$sid'";
            $res2 = $obj->executeQuery($con, $sql2);
            $tes2 = $res2['1'];
            $cid = [];
            foreach ($tes2 as $a){
                foreach ($a as $b){
                    $cid[] = $b;
                }
            }
            // Using course ID to obtain course information
            foreach ($cid as $v){
                $sql3 = "SELECT * FROM `Courses` WHERE c_id=$v";
                //$res3 = $obj->executeSelectQuery($con, $sql3);
                //$tes3 = mysqli_fetch_assoc($res3);
                $res3 = $obj->executeSelectQuery($con, $sql3);
                $tes3 = mysqli_fetch_assoc($res3);
                $ctitle = $tes3['title'];
                $date = $tes3['date'];
                $instructor = $tes3['instructor'];
                
                // Converting received date from database to a more readable format for the start date, then adding 3 weeks for the end date of that course
                $d2 = explode('-', $date);
                $d3 = $d2['1'].'/'.$d2['2'].'/'.$d2['0'];
                $d4 = strtotime($d3);
                $d5 = date('d/M/Y', $d4);
                $d6 = strtotime('5 weeks', $d4);
                $d7 = date('d/M/Y', $d6);

                echo '<div style="font-size:20px">'.$ctitle.' | '.$d5.' | '.$d7.' | '.$instructor.'</div>';
            }
            echo '</div>';
        }
    
        catch (Exception $e)
        {
            echo '<div class="container text-center" style=" 
            background: white;
            border-radius: 50px;padding-top:10px;padding-bottom:10px">';
            echo '<div style="font-size:20px"><b> Current Enrolled Courses </b></div>';
                echo '<div style="font-size:20px"><b> No currently assigned courses </b></div>';
            echo '</div>';
        }
    }   
?>
<?php require_once 'footer.php';?>
</body>
</html>
